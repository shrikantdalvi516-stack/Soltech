# SOLTECH Monitoring System

**Solar Powered EV Charging Station — monitoring & management dashboard**

Project Owner / Lead Developer: **Mr. Aryan Dalvi**
Developers: Mr. Aryan Dalvi · Mr. Omkar Gunjal · Mr. Kartik Gulve

---

## 1. Overview

SOLTECH is a full-stack, real-time monitoring dashboard for a solar-powered EV
charging station. It includes:

- Secure admin login (JWT-based, credentials from environment variables only)
- Live dashboard with KPI cards, energy flow diagram, weather, and alerts
- Real-time sensor telemetry pushed over Socket.IO every 3 seconds
- EV Charging Control with **Auto** and **Manual** modes, start/pause/stop
  controls, and confirmation dialogs for critical actions
- Solar Analytics with Recharts graphs (Live / Today / 7 Days / 30 Days)
- Live weather (OpenWeather API) with a solar-performance correlation view
- Historical data with CSV export
- Notifications / Alerts feed
- Project Change Catalogue (versioned changelog, extendable from the UI)
- "About Developers" zig-zag profile section
- Fully responsive (desktop, laptop, tablet, mobile) with a collapsible
  sidebar / hamburger menu

A **Mock Sensor Data Service** simulates realistic solar and EV charging
values out of the box, so the whole app runs and looks fully alive with no
physical hardware attached. It is built with a clean interface so it can be
swapped for a `RealIoTSensorService` later — see section 10.

---

## 2. Technologies

**Frontend:** React 18, Vite, Tailwind CSS, React Router, Recharts,
Lucide React icons, Socket.IO client, Axios

**Backend:** Node.js, Express, Socket.IO, JWT auth, express-rate-limit,
cookie-parser, cors, dotenv

**Data:** JSON file-based store for history/alerts/changelog (prototype).
Structured so it can be swapped for SQLite/MySQL/PostgreSQL later without
touching the routes' request/response shape.

---

## 3. Project Structure

```
soltech-monitoring/
├── client/                 # React + Vite frontend
│   ├── public/
│   │   ├── logo/soltech-logo.svg
│   │   └── developers/     # aryan.svg, omkar.svg, kartik.svg placeholders
│   └── src/
│       ├── components/     # Sidebar, Header, StatCard, ConfirmModal, etc.
│       ├── pages/          # one file per route/page
│       ├── charts/         # Recharts wrappers
│       ├── services/       # api.js (axios), socket.js (Socket.IO client)
│       └── context/        # AuthContext
├── server/                  # Express backend
│   ├── routes/              # auth, monitoring, charging, weather, history
│   ├── middleware/auth.js   # JWT verification
│   ├── services/
│   │   ├── mockSensorService.js   # simulated IoT data generator
│   │   └── weatherService.js      # OpenWeather wrapper (falls back to mock)
│   ├── data/                 # history.json, alerts.json, changelog.json
│   └── server.js
├── public/                   # reference copies of logo/developer assets
├── .env.example
└── README.md
```

---

## 4. Installation

You'll need **Node.js 18+** installed locally (this was built and packaged
in a sandbox without internet access, so `npm install` has not been run —
you'll do that on your own machine).

```bash
cd soltech-monitoring
npm run install:all
```

This installs dependencies for both `server/` and `client/`. (Or run
`npm install` inside each folder separately.)

---

## 5. Environment Variables

Copy the example env file into the server folder:

```bash
cp .env.example server/.env
```

Then edit `server/.env`:

```
PORT=5000
NODE_ENV=development
CLIENT_URL=http://localhost:5173

LOGIN_EMAIL=soltech238@gmail.com
LOGIN_PASSWORD=SOLTECH
JWT_SECRET=change_this_to_a_long_random_secret
JWT_EXPIRES_IN=8h

WEATHER_API_KEY=your_openweathermap_api_key_here
WEATHER_CITY=Pune,IN

DATA_MODE=MOCK
```

**Never commit `.env` to version control** and never hardcode these values
inside any React/JavaScript file in `client/`. The frontend never sees the
password — it only ever calls `POST /api/auth/login`, and the backend
compares against `process.env.LOGIN_EMAIL` / `LOGIN_PASSWORD`.

---

## 6. Running the app

From the project root, run both servers together:

```bash
npm run dev
```

Or run them separately in two terminals:

```bash
# Terminal 1
cd server && npm run dev      # http://localhost:5000

# Terminal 2
cd client && npm run dev      # http://localhost:5173
```

Open **http://localhost:5173**, log in with the credentials from your
`.env` file, and you'll land on `/dashboard`.

---

## 7. Login Configuration

Login is validated purely against `LOGIN_EMAIL` / `LOGIN_PASSWORD` in
`server/.env`. On success the server issues a JWT (also set as an
HTTP-only cookie) which the frontend stores and attaches as a Bearer token
on subsequent API calls. All `/api/*` routes except `/api/auth/login` are
protected by `middleware/auth.js`.

To change the admin credentials, just edit the two env values — no code
changes required.

---

## 8. Weather API Configuration

1. Get a free API key from https://openweathermap.org/api
2. Set `WEATHER_API_KEY` and `WEATHER_CITY` in `server/.env`
3. Restart the server

If no key is configured, `/api/weather` automatically returns clearly
labeled **simulated** weather data (`source: "MOCK"`) so the UI still works.
The API key is only ever used server-side in `services/weatherService.js`
and is never exposed to the browser.

---

## 9. Mock IoT Mode

`DATA_MODE=MOCK` (default) drives `server/services/mockSensorService.js`,
which generates realistic, continuously-evolving solar and EV charging
values (voltage, current, power, temperature, efficiency, battery %, etc.)
using a day-based solar irradiance curve and random-walk noise. Every
snapshot response includes `"dataMode": "MOCK"` so the UI can clearly badge
it as **DEMO / MOCK DATA MODE**. Estimated efficiency values are always
labeled `efficiencyIsEstimated: true` and shown with an "Estimated" hint —
they are never presented as real hardware measurements.

---

## 10. Replacing Mock Data with Real Sensors

The mock service exposes a fixed interface:

```js
getSnapshot(), getRecentHistory(), getState(),
startCharging(), pauseCharging(), stopCharging(),
setMode(), setChargingLimit(), setGridSupport(),
setMonitoring(), setSystemPower()
```

To go live:

1. Create `server/services/realIoTSensorService.js` implementing the same
   function names/signatures, reading from your actual hardware (ESP32 /
   Arduino over WiFi or Serial, an MQTT broker topic, Modbus registers on
   the solar inverter, or the EV charger's REST API).
2. In `server/server.js` and the route files, swap:
   ```js
   const sensorService = require("./services/mockSensorService");
   ```
   for:
   ```js
   const sensorService = require("./services/realIoTSensorService");
   ```
3. Nothing else changes — routes, Socket.IO broadcast, and the entire
   frontend keep working unmodified.

Planned/possible REST endpoints are already scaffolded:
`GET /api/monitoring`, `GET /api/solar` (via monitoring), `GET /api/weather`,
`GET /api/charging`, `POST /api/charging/start|pause|stop`,
`POST /api/system/power`, `POST /api/system/mode`.

---

## 11. Adding Developer Photos

Placeholder SVG avatars ship in `client/public/developers/` (`aryan.svg`,
`omkar.svg`, `kartik.svg`) — no real photographs were invented.

To add real photos:
1. Drop `aryan.jpg`, `omkar.jpg`, `kartik.jpg` into `client/public/developers/`
2. Update the `photo` prop in `client/src/pages/Dashboard.jsx` and
   `client/src/pages/AboutDevelopers.jsx` from `/developers/aryan.svg` to
   `/developers/aryan.jpg` (and likewise for the others)

Same process for the SOLTECH logo — replace
`client/public/logo/soltech-logo.svg` with your real logo file and update
the `<img src>` references (Sidebar, Login, Dashboard) if the filename
changes.

---

## 12. Building for Production

```bash
cd client
npm run build
```

This outputs a static build in `client/dist/`, which can be served by any
static host or by Express itself. For a simple single-server deployment,
serve `client/dist` as static files from `server.js` and reverse-proxy
`/api` and the Socket.IO path as needed. Run the backend with
`NODE_ENV=production` and a strong, randomly generated `JWT_SECRET`.

---

## 13. Security Notes

- Credentials live only in `server/.env`, never in frontend source
- JWT stored client-side in `localStorage` + an HTTP-only cookie fallback
- `express-rate-limit` throttles repeated login attempts
- All monitoring/charging/history/weather routes require a valid JWT
- CORS is restricted to `CLIENT_URL`
- Critical actions (System OFF, Stop Charging) require an explicit
  confirmation dialog on the frontend before the API call fires

This is a prototype/demo-grade security setup suitable for a single-admin
monitoring tool. For multi-user production use, add a real user table with
hashed passwords (`bcryptjs` is already a dependency), refresh tokens, and
HTTPS termination in front of the Node server.
