import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import ProtectedRoute from "./components/ProtectedRoute.jsx";

import Login from "./pages/Login.jsx";
import Dashboard from "./pages/Dashboard.jsx";
import RealTimeMonitoring from "./pages/RealTimeMonitoring.jsx";
import EVChargingControl from "./pages/EVChargingControl.jsx";
import SolarAnalytics from "./pages/SolarAnalytics.jsx";
import Weather from "./pages/Weather.jsx";
import EnergyHistory from "./pages/EnergyHistory.jsx";
import Alerts from "./pages/Alerts.jsx";
import ChangeCatalogue from "./pages/ChangeCatalogue.jsx";
import AboutDevelopers from "./pages/AboutDevelopers.jsx";
import Settings from "./pages/Settings.jsx";

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />

      <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
      <Route path="/realtime" element={<ProtectedRoute><RealTimeMonitoring /></ProtectedRoute>} />
      <Route path="/charging" element={<ProtectedRoute><EVChargingControl /></ProtectedRoute>} />
      <Route path="/analytics" element={<ProtectedRoute><SolarAnalytics /></ProtectedRoute>} />
      <Route path="/weather" element={<ProtectedRoute><Weather /></ProtectedRoute>} />
      <Route path="/history" element={<ProtectedRoute><EnergyHistory /></ProtectedRoute>} />
      <Route path="/alerts" element={<ProtectedRoute><Alerts /></ProtectedRoute>} />
      <Route path="/catalogue" element={<ProtectedRoute><ChangeCatalogue /></ProtectedRoute>} />
      <Route path="/developers" element={<ProtectedRoute><AboutDevelopers /></ProtectedRoute>} />
      <Route path="/settings" element={<ProtectedRoute><Settings /></ProtectedRoute>} />

      <Route path="/" element={<Navigate to="/dashboard" replace />} />
      <Route path="*" element={<Navigate to="/dashboard" replace />} />
    </Routes>
  );
}
