import React from "react";
import { Phone, Mail } from "lucide-react";

export default function DeveloperCard({ name, role, photo, phone, email, reverse }) {
  return (
    <div
      className={`flex flex-col ${
        reverse ? "md:flex-row-reverse" : "md:flex-row"
      } items-center gap-6 md:gap-10 card p-6`}
    >
      <img
        src={photo}
        alt={`${name} photo`}
        className="w-32 h-32 md:w-40 md:h-40 rounded-2xl object-cover border border-white/10 shrink-0"
      />
      <div className={`space-y-2 ${reverse ? "md:text-right" : "md:text-left"} text-center md:text-left`}>
        <h3 className="text-lg font-bold">{name}</h3>
        <p className="text-solar-400 text-sm">{role}</p>
        <div className={`flex flex-col gap-1.5 text-sm text-slate-400 ${reverse ? "md:items-end" : ""}`}>
          <span className="flex items-center gap-2">
            <Phone size={14} /> {phone}
          </span>
          {email && (
            <span className="flex items-center gap-2">
              <Mail size={14} /> {email}
            </span>
          )}
        </div>
      </div>
    </div>
  );
}
