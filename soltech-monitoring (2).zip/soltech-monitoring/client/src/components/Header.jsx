import React, { useEffect, useState } from "react";
import { Menu, Wifi, User } from "lucide-react";
import { useAuth } from "../context/AuthContext.jsx";

function formatDateTime(date) {
  const dateStr = date.toLocaleDateString("en-IN", {
    day: "2-digit",
    month: "long",
    year: "numeric",
    timeZone: "Asia/Kolkata",
  });
  const timeStr = date.toLocaleTimeString("en-IN", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: true,
    timeZone: "Asia/Kolkata",
  });
  return { dateStr, timeStr };
}

export default function Header({ title, subtitle, onMenuClick, systemStatus = "ONLINE" }) {
  const [now, setNow] = useState(new Date());
  const { user } = useAuth();

  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  const { dateStr, timeStr } = formatDateTime(now);

  return (
    <header className="sticky top-0 z-20 bg-graphite-950/90 backdrop-blur border-b border-white/5 px-4 lg:px-8 py-4 flex items-center justify-between gap-4">
      <div className="flex items-center gap-3 min-w-0">
        <button onClick={onMenuClick} className="lg:hidden text-slate-300">
          <Menu size={22} />
        </button>
        <div className="min-w-0">
          <h1 className="text-base lg:text-lg font-bold truncate">{title}</h1>
          {subtitle && <p className="text-xs text-slate-400 truncate">{subtitle}</p>}
        </div>
      </div>

      <div className="hidden md:flex items-center gap-4 text-xs text-slate-400">
        <div className="text-right">
          <p className="text-slate-200 font-medium">{dateStr}</p>
          <p className="tabular-nums">{timeStr} IST</p>
        </div>
        <span className="badge bg-solar-600/15 text-solar-400">
          <Wifi size={12} /> {systemStatus}
        </span>
      </div>

      <div className="flex items-center gap-2 pl-3 border-l border-white/10">
        <div className="w-8 h-8 rounded-full bg-solar-600/20 flex items-center justify-center text-solar-400">
          <User size={16} />
        </div>
        <div className="hidden sm:block">
          <p className="text-xs font-medium">{user?.email || "Admin"}</p>
          <p className="text-[10px] text-slate-500">Administrator</p>
        </div>
      </div>
    </header>
  );
}
