import React from "react";
import { NavLink } from "react-router-dom";
import {
  LayoutDashboard,
  Activity,
  BatteryCharging,
  LineChart,
  CloudSun,
  History,
  BellRing,
  ClipboardList,
  Users,
  Settings,
  LogOut,
  X,
  Sun,
} from "lucide-react";
import { useAuth } from "../context/AuthContext.jsx";

const NAV_ITEMS = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { to: "/realtime", label: "Real-Time Monitoring", icon: Activity },
  { to: "/charging", label: "EV Charging Control", icon: BatteryCharging },
  { to: "/analytics", label: "Solar Analytics", icon: LineChart },
  { to: "/weather", label: "Weather", icon: CloudSun },
  { to: "/history", label: "Energy History", icon: History },
  { to: "/alerts", label: "Alerts", icon: BellRing },
  { to: "/catalogue", label: "Project Change Catalogue", icon: ClipboardList },
  { to: "/developers", label: "About Developers", icon: Users },
  { to: "/settings", label: "Settings", icon: Settings },
];

export default function Sidebar({ open, onClose }) {
  const { logout } = useAuth();

  return (
    <>
      {open && (
        <div
          className="fixed inset-0 bg-black/50 z-30 lg:hidden"
          onClick={onClose}
        />
      )}
      <aside
        className={`fixed lg:sticky top-0 left-0 h-screen w-72 bg-graphite-900 border-r border-white/5 z-40
        flex flex-col transition-transform duration-200 lg:translate-x-0
        ${open ? "translate-x-0" : "-translate-x-full"}`}
      >
        <div className="flex items-center justify-between px-5 py-5 border-b border-white/5">
          <div className="flex items-center gap-3">
            <img src="/logo/soltech-logo.jpg" alt="SOLTECH logo" className="w-9 h-9" />
            <div>
              <p className="font-bold text-sm leading-tight">SOLTECH</p>
              <p className="text-[11px] text-slate-400 leading-tight">Monitoring System</p>
            </div>
          </div>
          <button onClick={onClose} className="lg:hidden text-slate-400">
            <X size={20} />
          </button>
        </div>

        <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-1">
          {NAV_ITEMS.map(({ to, label, icon: Icon }) => (
            <NavLink
              key={to}
              to={to}
              onClick={onClose}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition-colors ${
                  isActive
                    ? "bg-solar-600/15 text-solar-400 font-medium"
                    : "text-slate-400 hover:bg-white/5 hover:text-slate-200"
                }`
              }
            >
              <Icon size={18} />
              {label}
            </NavLink>
          ))}
        </nav>

        <div className="p-3 border-t border-white/5 space-y-1">
          <div className="flex items-center gap-2 px-3 py-2 text-xs text-solar-400">
            <Sun size={14} /> Green Energy Powered
          </div>
          <button
            onClick={logout}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm text-red-400 hover:bg-red-500/10 transition-colors"
          >
            <LogOut size={18} />
            Logout
          </button>
        </div>
      </aside>
    </>
  );
}
