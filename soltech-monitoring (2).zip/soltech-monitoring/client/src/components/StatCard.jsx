import React from "react";

export default function StatCard({ icon: Icon, label, value, unit, accent = "text-solar-400", hint }) {
  return (
    <div className="card p-4 lg:p-5 flex flex-col gap-3 hover:border-solar-600/30 transition-colors">
      <div className="flex items-center justify-between">
        <span className="text-xs text-slate-400">{label}</span>
        {Icon && (
          <div className={`w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center ${accent}`}>
            <Icon size={16} />
          </div>
        )}
      </div>
      <div className="flex items-end gap-1">
        <span className="text-2xl font-bold tabular-nums">{value}</span>
        {unit && <span className="text-sm text-slate-400 mb-0.5">{unit}</span>}
      </div>
      {hint && <span className="text-[11px] text-slate-500">{hint}</span>}
    </div>
  );
}
