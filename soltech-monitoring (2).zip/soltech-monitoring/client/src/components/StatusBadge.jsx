import React from "react";

const COLORS = {
  ONLINE: "bg-solar-600/15 text-solar-400",
  OFFLINE: "bg-red-500/15 text-red-400",
  GENERATING: "bg-solar-600/15 text-solar-400",
  IDLE: "bg-slate-500/15 text-slate-400",
  READY: "bg-sky-500/15 text-sky-400",
  CHARGING: "bg-solar-600/15 text-solar-400",
  PAUSED: "bg-amber-500/15 text-amber-400",
  STOPPED: "bg-red-500/15 text-red-400",
  CONNECTED: "bg-solar-600/15 text-solar-400",
  DISCONNECTED: "bg-red-500/15 text-red-400",
  ACTIVE: "bg-solar-600/15 text-solar-400",
  STANDBY: "bg-slate-500/15 text-slate-400",
  ON: "bg-solar-600/15 text-solar-400",
  OFF: "bg-slate-500/15 text-slate-400",
};

export default function StatusBadge({ status }) {
  const color = COLORS[status] || "bg-slate-500/15 text-slate-400";
  return (
    <span className={`badge ${color}`}>
      <span className="w-1.5 h-1.5 rounded-full bg-current" />
      {status}
    </span>
  );
}
