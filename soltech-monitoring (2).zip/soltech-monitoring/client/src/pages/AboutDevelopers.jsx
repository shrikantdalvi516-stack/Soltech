import React from "react";
import DashboardLayout from "../components/DashboardLayout.jsx";
import DeveloperCard from "../components/DeveloperCard.jsx";

export default function AboutDevelopers() {
  return (
    <DashboardLayout title="About Developers" subtitle="The team behind SOLTECH Monitoring System">
      <div className="text-center mb-6">
        <h2 className="text-xl font-bold">SOLTECH MONITORING SYSTEM</h2>
        <p className="text-slate-400 text-sm">Developed by</p>
      </div>

      <div className="space-y-6 max-w-3xl mx-auto">
        <DeveloperCard
          name="Mr. Aryan Dalvi"
          role="Project Owner / Lead Developer"
          photo="/developers/aryan.jpg"
          phone="+91 7249738125"
          email="soltech238@gmail.com"
        />
        <DeveloperCard
          name="Mr. Omkar Gunjal"
          role="Developer"
          photo="/developers/omkar.jpg"
          phone="+91 9284498093"
          email="omkargunjal4777@gmail.com"
          reverse
        />
        <DeveloperCard
          name="Mr. Kartik Gulve"
          role="Developer"
          photo="/developers/kartik.jpg"
          phone="+91 7972742175"
          email="Kartikgulve08@gmail.com"
        />
      </div>
    </DashboardLayout>
  );
}
