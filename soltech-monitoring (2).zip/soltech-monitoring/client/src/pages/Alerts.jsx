import React, { useEffect, useState } from "react";
import DashboardLayout from "../components/DashboardLayout.jsx";
import api from "../services/api";
import { AlertTriangle, Info, CheckCircle2, XCircle } from "lucide-react";

const LEVEL_STYLES = {
  info: { icon: Info, class: "bg-sky-500/15 text-sky-400" },
  success: { icon: CheckCircle2, class: "bg-solar-600/15 text-solar-400" },
  warning: { icon: AlertTriangle, class: "bg-amber-500/15 text-amber-400" },
  error: { icon: XCircle, class: "bg-red-500/15 text-red-400" },
};

export default function Alerts() {
  const [alerts, setAlerts] = useState([]);

  useEffect(() => {
    api.get("/history/alerts").then((res) => setAlerts(res.data));
  }, []);

  return (
    <DashboardLayout title="Notifications / Alerts" subtitle="System events and warnings">
      <div className="card divide-y divide-white/5">
        {alerts.map((a) => {
          const style = LEVEL_STYLES[a.level] || LEVEL_STYLES.info;
          const Icon = style.icon;
          return (
            <div key={a.id} className="flex items-start gap-4 p-4">
              <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${style.class}`}>
                <Icon size={18} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2">
                  <p className="font-medium text-sm">{a.type}</p>
                  <span className="text-[11px] text-slate-500 whitespace-nowrap">
                    {new Date(a.timestamp).toLocaleString("en-IN", { timeZone: "Asia/Kolkata" })}
                  </span>
                </div>
                <p className="text-xs text-slate-400 mt-0.5">{a.message}</p>
              </div>
            </div>
          );
        })}
        {alerts.length === 0 && (
          <p className="text-center text-slate-500 py-10 text-sm">No alerts to show.</p>
        )}
      </div>
    </DashboardLayout>
  );
}
