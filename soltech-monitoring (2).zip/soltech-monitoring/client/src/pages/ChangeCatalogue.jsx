import React, { useEffect, useState } from "react";
import DashboardLayout from "../components/DashboardLayout.jsx";
import api from "../services/api";
import { Plus } from "lucide-react";

const emptyForm = { version: "", date: "", feature: "", description: "", developer: "", status: "Completed" };

export default function ChangeCatalogue() {
  const [rows, setRows] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(emptyForm);

  const load = () => api.get("/history/changelog").then((res) => setRows(res.data));

  useEffect(() => {
    load();
  }, []);

  const submit = async (e) => {
    e.preventDefault();
    await api.post("/history/changelog", form);
    setForm(emptyForm);
    setShowForm(false);
    load();
  };

  return (
    <DashboardLayout title="Project Change Catalogue" subtitle="Version history of all changes made to SOLTECH">
      <div className="flex justify-end">
        <button
          onClick={() => setShowForm((s) => !s)}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-solar-600 hover:bg-solar-700 text-sm font-medium"
        >
          <Plus size={16} /> Add Entry
        </button>
      </div>

      {showForm && (
        <form onSubmit={submit} className="card p-5 grid grid-cols-1 sm:grid-cols-2 gap-4">
          {["version", "date", "feature", "developer"].map((field) => (
            <input
              key={field}
              required
              placeholder={field[0].toUpperCase() + field.slice(1)}
              value={form[field]}
              onChange={(e) => setForm({ ...form, [field]: e.target.value })}
              className="bg-graphite-900 border border-white/10 rounded-xl px-3 py-2 text-sm"
            />
          ))}
          <textarea
            placeholder="Description"
            value={form.description}
            onChange={(e) => setForm({ ...form, description: e.target.value })}
            className="bg-graphite-900 border border-white/10 rounded-xl px-3 py-2 text-sm sm:col-span-2"
            rows={2}
          />
          <button type="submit" className="sm:col-span-2 bg-solar-600 hover:bg-solar-700 rounded-xl py-2 text-sm font-medium">
            Save Entry
          </button>
        </form>
      )}

      <div className="card overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-xs text-slate-400 border-b border-white/10">
              <th className="px-4 py-3">Version</th>
              <th className="px-4 py-3">Date</th>
              <th className="px-4 py-3">Feature / Change</th>
              <th className="px-4 py-3">Description</th>
              <th className="px-4 py-3">Developer</th>
              <th className="px-4 py-3">Status</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r, i) => (
              <tr key={i} className="border-b border-white/5 last:border-0 hover:bg-white/5">
                <td className="px-4 py-3 font-medium">{r.version}</td>
                <td className="px-4 py-3">{r.date}</td>
                <td className="px-4 py-3">{r.feature}</td>
                <td className="px-4 py-3 text-slate-400">{r.description}</td>
                <td className="px-4 py-3">{r.developer}</td>
                <td className="px-4 py-3 text-solar-400">{r.status}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </DashboardLayout>
  );
}
