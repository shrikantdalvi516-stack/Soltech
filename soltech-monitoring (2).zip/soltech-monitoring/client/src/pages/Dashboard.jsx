import React, { useEffect, useState } from "react";
import {
  Sun,
  Zap,
  BatteryCharging,
  Gauge,
  Battery,
  Plug,
  Activity,
  CloudSun,
  ArrowDown,
} from "lucide-react";
import DashboardLayout from "../components/DashboardLayout.jsx";
import StatCard from "../components/StatCard.jsx";
import StatusBadge from "../components/StatusBadge.jsx";
import DeveloperCard from "../components/DeveloperCard.jsx";
import api from "../services/api";
import { getSocket } from "../services/socket";

export default function Dashboard() {
  const [snapshot, setSnapshot] = useState(null);
  const [weather, setWeather] = useState(null);
  const [alerts, setAlerts] = useState([]);

  useEffect(() => {
    api.get("/monitoring").then((res) => setSnapshot(res.data));
    api.get("/weather").then((res) => setWeather(res.data));
    api.get("/history/alerts").then((res) => setAlerts(res.data.slice(0, 4)));

    const socket = getSocket();
    socket.on("monitoring:update", setSnapshot);
    return () => socket.off("monitoring:update", setSnapshot);
  }, []);

  if (!snapshot) {
    return (
      <DashboardLayout title="SOLTECH Monitoring System" subtitle="Solar Powered EV Charging Station">
        <div className="card p-10 text-center text-slate-400">Loading dashboard data...</div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout
      title="SOLTECH Monitoring System"
      subtitle="Solar Powered EV Charging Station"
      systemStatus={snapshot.systemPower === "ON" ? "ONLINE" : "OFFLINE"}
    >
      {snapshot.dataMode === "MOCK" && (
        <div className="badge bg-amber-500/15 text-amber-400 w-fit">DEMO / MOCK DATA MODE — no live hardware connected</div>
      )}

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        <StatCard icon={Sun} label="Solar Power Generated" value={snapshot.solar.powerKw} unit="kW" />
        <StatCard icon={Zap} label="Current Solar Power" value={snapshot.solar.powerKw} unit="kW" />
        <StatCard icon={Activity} label="Today's Energy" value={snapshot.energy.todaysEnergyKwh} unit="kWh" />
        <StatCard icon={Gauge} label="Total Energy Generated" value={snapshot.energy.totalEnergyKwh} unit="kWh" />
        <StatCard icon={BatteryCharging} label="EV Charging Power" value={snapshot.ev.powerKw} unit="kW" />
        <StatCard icon={Plug} label="Energy Used for EV Charging" value={snapshot.ev.energyDeliveredKwh} unit="kWh" />
        <StatCard icon={Gauge} label="Solar Panel Efficiency" value={snapshot.solar.panelEfficiencyPercent} unit="%" hint="Estimated" />
        <StatCard icon={Activity} label="Charging Station Status" value={snapshot.ev.status} />
        <StatCard icon={Battery} label="EV Battery" value={snapshot.ev.batteryPercent} unit="%" />
        <StatCard icon={ArrowDown} label="Grid Power Usage" value={snapshot.grid.powerKw} unit="kW" />
      </div>

      {/* Energy Flow + Weather + Alerts row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="card p-5 lg:col-span-2">
          <h3 className="font-semibold mb-4">Energy Flow</h3>
          <EnergyFlowDiagram snapshot={snapshot} />
        </div>

        <div className="card p-5">
          <h3 className="font-semibold mb-4 flex items-center gap-2">
            <CloudSun size={16} className="text-solar-400" /> Live Weather
          </h3>
          {weather ? (
            <div className="space-y-2 text-sm">
              <p className="text-2xl font-bold">{weather.temperature}°C</p>
              <p className="text-slate-400">{weather.condition}</p>
              <div className="grid grid-cols-2 gap-2 text-xs text-slate-400 pt-2">
                <span>Humidity: {weather.humidity}%</span>
                <span>Wind: {weather.windSpeed} m/s</span>
                <span>Cloud: {weather.cloudPercent}%</span>
                <span>UV: {weather.uvIndex ?? "N/A"}</span>
              </div>
              {weather.source === "MOCK" && (
                <p className="text-[10px] text-amber-400 pt-1">Simulated weather (no API key configured)</p>
              )}
            </div>
          ) : (
            <p className="text-sm text-slate-400">Loading weather...</p>
          )}
        </div>
      </div>

      {/* System Status + Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="card p-5">
          <h3 className="font-semibold mb-4">System Status</h3>
          <div className="grid grid-cols-2 gap-3 text-sm">
            <StatusRow label="System Status" status={snapshot.systemPower === "ON" ? "ONLINE" : "OFFLINE"} />
            <StatusRow label="Solar Status" status={snapshot.solar.powerKw > 0.1 ? "GENERATING" : "IDLE"} />
            <StatusRow label="EV Charger" status={snapshot.ev.status} />
            <StatusRow label="Monitoring" status={snapshot.monitoring === "ON" ? "ACTIVE" : "STANDBY"} />
            <StatusRow label="Internet" status="CONNECTED" />
            <StatusRow label="Weather API" status={weather?.source === "LIVE" ? "CONNECTED" : "CONNECTED"} />
          </div>
        </div>

        <div className="card p-5">
          <h3 className="font-semibold mb-4">Recent Alerts</h3>
          <ul className="space-y-3">
            {alerts.map((a) => (
              <li key={a.id} className="flex items-start justify-between text-sm border-b border-white/5 pb-2 last:border-0">
                <div>
                  <p className="font-medium">{a.type}</p>
                  <p className="text-xs text-slate-500">{a.message}</p>
                </div>
                <span className="text-[10px] text-slate-500 whitespace-nowrap ml-2">
                  {new Date(a.timestamp).toLocaleDateString("en-IN")}
                </span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* About Developers */}
      <div id="developers" className="pt-4">
        <h2 className="text-lg font-bold text-center mb-1">SOLTECH MONITORING SYSTEM</h2>
        <p className="text-center text-sm text-slate-400 mb-6">Developed by</p>
        <div className="space-y-5 max-w-3xl mx-auto">
          <DeveloperCard
            name="Mr. Aryan Dalvi"
            role="Project Owner / Lead Developer"
            photo="/developers/aryan.jpg"
            phone="+91 7249738125"
            email="soltech238@gmail.com"
          />
          <DeveloperCard
            name="Mr. Omkar Gunjal"
            role="Developer"
            photo="/developers/omkar.jpg"
            phone="+91 9284498093"
            email="omkargunjal4777@gmail.com"
            reverse
          />
          <DeveloperCard
            name="Mr. Kartik Gulve"
            role="Developer"
            photo="/developers/kartik.jpg"
            phone="+91 7972742175"
            email="Kartikgulve08@gmail.com"
          />
        </div>
      </div>

      <footer className="text-center text-xs text-slate-500 pt-8 pb-4 space-y-1">
        <p className="font-semibold text-slate-300">SOLTECH MONITORING SYSTEM</p>
        <p>Solar Powered EV Charging Station</p>
        <p className="text-solar-400">"Empower India with Clean Solar Solutions"</p>
        <p className="pt-2">Developed by Mr. Aryan Dalvi · Mr. Omkar Gunjal · Mr. Kartik Gulve</p>
      </footer>
    </DashboardLayout>
  );
}

function StatusRow({ label, status }) {
  return (
    <div className="flex items-center justify-between bg-white/5 rounded-xl px-3 py-2">
      <span className="text-slate-400 text-xs">{label}</span>
      <StatusBadge status={status} />
    </div>
  );
}

function EnergyFlowDiagram({ snapshot }) {
  const flowing = snapshot.solar.powerKw > 0.1;
  const evFlowing = snapshot.ev.powerKw > 0.1;

  const Node = ({ label, sub }) => (
    <div className="card bg-graphite-900 px-4 py-3 text-center min-w-[120px]">
      <p className="text-sm font-semibold">{label}</p>
      {sub && <p className="text-xs text-slate-400">{sub}</p>}
    </div>
  );

  const Arrow = ({ active }) => (
    <svg width="40" height="24" className="mx-auto">
      <line
        x1="20" y1="0" x2="20" y2="20"
        stroke={active ? "#22c55e" : "#475569"}
        strokeWidth="2"
        className={active ? "flow-line" : ""}
      />
      <polygon points="14,18 26,18 20,24" fill={active ? "#22c55e" : "#475569"} />
    </svg>
  );

  return (
    <div className="flex flex-col items-center gap-1">
      <Node label="SOLAR PANELS" sub={`${snapshot.solar.powerKw} kW`} />
      <Arrow active={flowing} />
      <Node label="SOLAR CONTROLLER" />
      <Arrow active={flowing} />
      <Node label="EV CHARGING STATION" sub={snapshot.ev.status} />
      <Arrow active={evFlowing} />
      <Node label="EV" sub={`${snapshot.ev.batteryPercent}%`} />
      {snapshot.grid.supportActive && (
        <p className="text-xs text-amber-400 mt-2">+ Grid backup active ({snapshot.grid.powerKw} kW)</p>
      )}
    </div>
  );
}
