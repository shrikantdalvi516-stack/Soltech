import React, { useEffect, useState } from "react";
import DashboardLayout from "../components/DashboardLayout.jsx";
import StatCard from "../components/StatCard.jsx";
import StatusBadge from "../components/StatusBadge.jsx";
import ConfirmModal from "../components/ConfirmModal.jsx";
import api from "../services/api";
import { getSocket } from "../services/socket";
import { Play, Pause, Square, Zap, BatteryCharging, Clock } from "lucide-react";

function formatDuration(sec) {
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = Math.floor(sec % 60);
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

export default function EVChargingControl() {
  const [snapshot, setSnapshot] = useState(null);
  const [confirmAction, setConfirmAction] = useState(null); // 'start' | 'pause' | 'stop' | null
  const [limit, setLimit] = useState(7.4);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    api.get("/monitoring").then((res) => {
      setSnapshot(res.data);
      setLimit(res.data.ev.chargingPowerLimitKw);
    });
    const socket = getSocket();
    socket.on("monitoring:update", setSnapshot);
    return () => socket.off("monitoring:update", setSnapshot);
  }, []);

  const runAction = async (action) => {
    setBusy(true);
    try {
      if (action === "start") await api.post("/charging/start");
      if (action === "pause") await api.post("/charging/pause");
      if (action === "stop") await api.post("/charging/stop");
      const res = await api.get("/monitoring");
      setSnapshot(res.data);
    } finally {
      setBusy(false);
      setConfirmAction(null);
    }
  };

  const setMode = async (mode) => {
    await api.post("/monitoring/system/mode", { mode });
    const res = await api.get("/monitoring");
    setSnapshot(res.data);
  };

  const applyLimit = async () => {
    await api.post("/charging/limit", { kw: limit });
  };

  if (!snapshot) {
    return (
      <DashboardLayout title="EV Charging Control" subtitle="Station 01">
        <div className="card p-10 text-center text-slate-400">Loading charging station data...</div>
      </DashboardLayout>
    );
  }

  const isManual = snapshot.mode === "MANUAL";

  return (
    <DashboardLayout title="EV Charging Control" subtitle="Station 01">
      <div className="flex flex-wrap items-center gap-3">
        <button
          onClick={() => setMode("AUTO")}
          className={`px-4 py-2 rounded-xl text-sm font-medium transition-colors ${
            !isManual ? "bg-solar-600 text-white" : "bg-white/5 text-slate-400 hover:bg-white/10"
          }`}
        >
          AUTO MODE
        </button>
        <button
          onClick={() => setMode("MANUAL")}
          className={`px-4 py-2 rounded-xl text-sm font-medium transition-colors ${
            isManual ? "bg-solar-600 text-white" : "bg-white/5 text-slate-400 hover:bg-white/10"
          }`}
        >
          MANUAL MODE
        </button>
      </div>

      {!isManual ? (
        <div className="card p-5">
          <h3 className="font-semibold mb-3 flex items-center gap-2">
            <span className="badge bg-solar-600/15 text-solar-400">AUTO MODE ACTIVE</span>
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <StatCard icon={Zap} label="Solar Power Available" value={snapshot.solar.powerKw} unit="kW" />
            <StatCard icon={BatteryCharging} label="EV Charging" value={snapshot.ev.powerKw} unit="kW" />
            <StatCard label="Grid Support" value={snapshot.grid.supportActive ? "ON" : "OFF"} />
          </div>
          <p className="text-xs text-slate-500 mt-4">
            Charging power is automatically managed based on available solar generation to minimize grid usage.
            Switch to Manual Mode to take direct control.
          </p>
        </div>
      ) : (
        <div className="card p-5 space-y-5">
          <div className="flex items-center justify-between">
            <span className="text-sm text-slate-400">Vehicle</span>
            <StatusBadge status={snapshot.ev.connected ? "CONNECTED" : "DISCONNECTED"} />
          </div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <StatCard icon={BatteryCharging} label="Battery" value={snapshot.ev.batteryPercent} unit="%" />
            <StatCard icon={Zap} label="Charging Power" value={snapshot.ev.powerKw} unit="kW" />
            <StatCard icon={Zap} label="Charging Voltage" value={snapshot.ev.voltage} unit="V" />
            <StatCard icon={Zap} label="Charging Current" value={snapshot.ev.current} unit="A" />
          </div>
          <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
            <StatCard icon={Clock} label="Charging Time" value={formatDuration(snapshot.ev.chargingDurationSec)} />
            <StatCard label="Energy Delivered" value={snapshot.ev.energyDeliveredKwh} unit="kWh" />
            <StatCard icon={Clock} label="Est. Remaining Time" value={formatDuration(snapshot.ev.estRemainingSec)} />
          </div>

          <div className="flex items-center gap-3">
            <label className="text-xs text-slate-400 w-40">Charging Power Limit (kW)</label>
            <input
              type="range"
              min="1"
              max="22"
              step="0.5"
              value={limit}
              onChange={(e) => setLimit(Number(e.target.value))}
              onMouseUp={applyLimit}
              onTouchEnd={applyLimit}
              className="flex-1 accent-solar-500"
            />
            <span className="text-sm font-medium w-14 text-right">{limit} kW</span>
          </div>

          <div className="flex flex-wrap gap-3 pt-2">
            <button
              disabled={busy}
              onClick={() => setConfirmAction("start")}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-solar-600 hover:bg-solar-700 text-sm font-medium disabled:opacity-50"
            >
              <Play size={16} /> START CHARGING
            </button>
            <button
              disabled={busy}
              onClick={() => setConfirmAction("pause")}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-amber-500/20 text-amber-400 hover:bg-amber-500/30 text-sm font-medium disabled:opacity-50"
            >
              <Pause size={16} /> PAUSE CHARGING
            </button>
            <button
              disabled={busy}
              onClick={() => setConfirmAction("stop")}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-red-500/20 text-red-400 hover:bg-red-500/30 text-sm font-medium disabled:opacity-50"
            >
              <Square size={16} /> STOP CHARGING
            </button>
          </div>
        </div>
      )}

      <ConfirmModal
        open={!!confirmAction}
        title={
          confirmAction === "start"
            ? "Start Charging"
            : confirmAction === "pause"
            ? "Pause Charging"
            : "Stop Charging"
        }
        message={`Are you sure you want to ${confirmAction} the EV charging session for Station 01?`}
        confirmLabel={confirmAction === "start" ? "Start" : confirmAction === "pause" ? "Pause" : "Stop"}
        danger={confirmAction === "stop"}
        onCancel={() => setConfirmAction(null)}
        onConfirm={() => runAction(confirmAction)}
      />
    </DashboardLayout>
  );
}
