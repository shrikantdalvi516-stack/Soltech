import React, { useEffect, useState } from "react";
import DashboardLayout from "../components/DashboardLayout.jsx";
import api from "../services/api";
import { Download } from "lucide-react";

const RANGES = [
  { key: "today", label: "Today" },
  { key: "yesterday", label: "Yesterday" },
  { key: "7days", label: "Last 7 Days" },
  { key: "30days", label: "Last 30 Days" },
];

export default function EnergyHistory() {
  const [range, setRange] = useState("30days");
  const [rows, setRows] = useState([]);

  useEffect(() => {
    api.get(`/history?range=${range}`).then((res) => setRows(res.data));
  }, [range]);

  const exportCsv = () => {
    const token = localStorage.getItem("soltech_token");
    const url = `/api/history/export.csv?range=${range}`;
    fetch(url, { headers: { Authorization: `Bearer ${token}` } })
      .then((res) => res.blob())
      .then((blob) => {
        const link = document.createElement("a");
        link.href = window.URL.createObjectURL(blob);
        link.download = "soltech-history.csv";
        link.click();
      });
  };

  return (
    <DashboardLayout title="Energy History" subtitle="Historical generation & charging records">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap gap-2">
          {RANGES.map((r) => (
            <button
              key={r.key}
              onClick={() => setRange(r.key)}
              className={`px-4 py-2 rounded-xl text-xs font-medium transition-colors ${
                range === r.key ? "bg-solar-600 text-white" : "bg-white/5 text-slate-400 hover:bg-white/10"
              }`}
            >
              {r.label}
            </button>
          ))}
        </div>
        <button
          onClick={exportCsv}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-xs font-medium"
        >
          <Download size={14} /> Export CSV
        </button>
      </div>

      <div className="card overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-xs text-slate-400 border-b border-white/10">
              <th className="px-4 py-3">Date</th>
              <th className="px-4 py-3">Solar (kWh)</th>
              <th className="px-4 py-3">EV Charging (kWh)</th>
              <th className="px-4 py-3">Grid (kWh)</th>
              <th className="px-4 py-3">Efficiency</th>
              <th className="px-4 py-3">Charging Duration</th>
              <th className="px-4 py-3">Status</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r, i) => (
              <tr key={i} className="border-b border-white/5 last:border-0 hover:bg-white/5">
                <td className="px-4 py-3">{r.date}</td>
                <td className="px-4 py-3">{r.solarGenerationKwh}</td>
                <td className="px-4 py-3">{r.evChargingKwh}</td>
                <td className="px-4 py-3">{r.gridEnergyKwh}</td>
                <td className="px-4 py-3">{r.efficiencyPercent}%</td>
                <td className="px-4 py-3">{r.chargingDuration}</td>
                <td className="px-4 py-3 text-solar-400">{r.systemStatus}</td>
              </tr>
            ))}
            {rows.length === 0 && (
              <tr>
                <td colSpan={7} className="px-4 py-10 text-center text-slate-500">
                  No records found for this range.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </DashboardLayout>
  );
}
