import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Eye, EyeOff, Sun } from "lucide-react";
import { useAuth } from "../context/AuthContext.jsx";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      await login(email, password);
      navigate("/dashboard");
    } catch (err) {
      setError(err.response?.data?.message || "Invalid email or password");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-graphite-950 px-4 relative overflow-hidden">
      <div className="absolute -top-40 -left-40 w-96 h-96 bg-solar-600/10 rounded-full blur-3xl" />
      <div className="absolute -bottom-40 -right-40 w-96 h-96 bg-solar-500/10 rounded-full blur-3xl" />

      <div className="card w-full max-w-md p-8 relative z-10">
        <div className="flex flex-col items-center text-center mb-6">
          <img src="/logo/soltech-logo.jpg" alt="SOLTECH logo" className="w-16 h-16 mb-3" />
          <h1 className="text-xl font-bold">SOLTECH MONITORING SYSTEM</h1>
          <p className="text-sm text-slate-400 mt-1 flex items-center gap-1.5">
            <Sun size={14} className="text-solar-400" /> Solar Powered EV Charging Station
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-xs text-slate-400 mb-1 block">Email / Username</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="admin@soltech.com"
              className="w-full bg-graphite-900 border border-white/10 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-solar-500"
            />
          </div>

          <div>
            <label className="text-xs text-slate-400 mb-1 block">Password</label>
            <div className="relative">
              <input
                type={showPassword ? "text" : "password"}
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full bg-graphite-900 border border-white/10 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:border-solar-500 pr-10"
              />
              <button
                type="button"
                onClick={() => setShowPassword((s) => !s)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400"
              >
                {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
          </div>

          {error && (
            <p className="text-sm text-red-400 bg-red-500/10 border border-red-500/20 rounded-xl px-3 py-2">
              {error}
            </p>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-solar-600 hover:bg-solar-700 disabled:opacity-60 transition-colors rounded-xl py-2.5 font-semibold text-sm"
          >
            {loading ? "Logging in..." : "LOGIN"}
          </button>
        </form>

        <p className="text-[11px] text-slate-500 text-center mt-6">
          Authorized administrator access only. Credentials are configured server-side via environment variables.
        </p>
      </div>
    </div>
  );
}
