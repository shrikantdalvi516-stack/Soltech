import React, { useEffect, useState } from "react";
import DashboardLayout from "../components/DashboardLayout.jsx";
import StatCard from "../components/StatCard.jsx";
import StatusBadge from "../components/StatusBadge.jsx";
import api from "../services/api";
import { getSocket } from "../services/socket";
import { Zap, Thermometer, Gauge, BatteryCharging, Clock } from "lucide-react";

function formatDuration(sec) {
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = Math.floor(sec % 60);
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

export default function RealTimeMonitoring() {
  const [snapshot, setSnapshot] = useState(null);
  const [now, setNow] = useState(new Date());

  useEffect(() => {
    api.get("/monitoring").then((res) => setSnapshot(res.data));
    const socket = getSocket();
    socket.on("monitoring:update", setSnapshot);
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => {
      socket.off("monitoring:update", setSnapshot);
      clearInterval(t);
    };
  }, []);

  if (!snapshot) {
    return (
      <DashboardLayout title="Real-Time Monitoring" subtitle="Live sensor telemetry">
        <div className="card p-10 text-center text-slate-400">Connecting to sensor stream...</div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout title="Real-Time Monitoring" subtitle="Live sensor telemetry — updates every 3 seconds">
      <div className="flex flex-wrap items-center gap-3">
        <span className={`badge ${snapshot.dataMode === "MOCK" ? "bg-amber-500/15 text-amber-400" : "bg-solar-600/15 text-solar-400"}`}>
          {snapshot.dataMode === "MOCK" ? "MOCK DATA MODE" : "LIVE HARDWARE MODE"}
        </span>
        <StatusBadge status={snapshot.monitoring === "ON" ? "ACTIVE" : "STANDBY"} />
        <span className="text-xs text-slate-400 flex items-center gap-1">
          <Clock size={12} />
          {now.toLocaleDateString("en-IN", { day: "2-digit", month: "long", year: "numeric", timeZone: "Asia/Kolkata" })}
          {" · "}
          {now.toLocaleTimeString("en-IN", { hour12: true, timeZone: "Asia/Kolkata" })} IST
        </span>
      </div>

      <div>
        <h3 className="font-semibold mb-3 text-sm text-slate-300">Solar Array</h3>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard icon={Zap} label="Solar Voltage" value={snapshot.solar.voltage} unit="V" />
          <StatCard icon={Zap} label="Solar Current" value={snapshot.solar.current} unit="A" />
          <StatCard icon={Gauge} label="Solar Power" value={snapshot.solar.powerKw} unit="kW" />
          <StatCard icon={Thermometer} label="Panel Temperature" value={snapshot.solar.panelTemp} unit="°C" />
        </div>
      </div>

      <div>
        <h3 className="font-semibold mb-3 text-sm text-slate-300">EV Charging</h3>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <StatCard icon={BatteryCharging} label="EV Charging Power" value={snapshot.ev.powerKw} unit="kW" />
          <StatCard icon={Zap} label="EV Charging Current" value={snapshot.ev.current} unit="A" />
          <StatCard icon={Zap} label="EV Charging Voltage" value={snapshot.ev.voltage} unit="V" />
          <StatCard icon={Gauge} label="Charging Percentage" value={snapshot.ev.batteryPercent} unit="%" />
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 mt-4">
          <StatCard icon={Clock} label="Charging Duration" value={formatDuration(snapshot.ev.chargingDurationSec)} />
          <StatCard icon={Clock} label="Est. Remaining Time" value={formatDuration(snapshot.ev.estRemainingSec)} />
          <StatCard icon={Thermometer} label="Station Temperature" value={snapshot.environment.ambientTemp} unit="°C" />
        </div>
      </div>

      <div className="card p-5">
        <h3 className="font-semibold mb-2">System Status</h3>
        <div className="flex flex-wrap gap-3">
          <StatusBadge status={snapshot.systemPower === "ON" ? "ONLINE" : "OFFLINE"} />
          <StatusBadge status={snapshot.ev.status} />
          <StatusBadge status={snapshot.mode} />
        </div>
      </div>
    </DashboardLayout>
  );
}
