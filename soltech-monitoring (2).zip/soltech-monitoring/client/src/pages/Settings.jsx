import React, { useEffect, useState } from "react";
import DashboardLayout from "../components/DashboardLayout.jsx";
import ConfirmModal from "../components/ConfirmModal.jsx";
import StatusBadge from "../components/StatusBadge.jsx";
import api from "../services/api";
import { getSocket } from "../services/socket";

function Toggle({ checked, onChange }) {
  return (
    <button
      onClick={() => onChange(!checked)}
      className={`w-12 h-7 rounded-full flex items-center px-1 transition-colors ${
        checked ? "bg-solar-600 justify-end" : "bg-white/10 justify-start"
      }`}
    >
      <span className="w-5 h-5 rounded-full bg-white block" />
    </button>
  );
}

export default function Settings() {
  const [snapshot, setSnapshot] = useState(null);
  const [confirmSystemOff, setConfirmSystemOff] = useState(false);
  const [monitoringWarning, setMonitoringWarning] = useState(false);

  useEffect(() => {
    api.get("/monitoring").then((res) => setSnapshot(res.data));
    const socket = getSocket();
    socket.on("monitoring:update", setSnapshot);
    return () => socket.off("monitoring:update", setSnapshot);
  }, []);

  const toggleMonitoring = async (on) => {
    await api.post("/monitoring/toggle", { on });
    if (!on) setMonitoringWarning(true);
    const res = await api.get("/monitoring");
    setSnapshot(res.data);
  };

  const toggleSystemPower = async (on) => {
    if (!on) {
      setConfirmSystemOff(true);
      return;
    }
    await api.post("/monitoring/system/power", { on: true });
    const res = await api.get("/monitoring");
    setSnapshot(res.data);
  };

  const confirmSystemOffAction = async () => {
    await api.post("/monitoring/system/power", { on: false });
    const res = await api.get("/monitoring");
    setSnapshot(res.data);
    setConfirmSystemOff(false);
  };

  const toggleGrid = async (on) => {
    await api.post("/monitoring/system/grid-support", { on });
    const res = await api.get("/monitoring");
    setSnapshot(res.data);
  };

  if (!snapshot) {
    return (
      <DashboardLayout title="Settings" subtitle="System configuration">
        <div className="card p-10 text-center text-slate-400">Loading...</div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout title="Settings" subtitle="System configuration & critical controls">
      <div className="card p-5 flex items-center justify-between">
        <div>
          <p className="font-medium text-sm">Real-Time Monitoring</p>
          <p className="text-xs text-slate-500">Live sensor polling and dashboard updates</p>
          {monitoringWarning && snapshot.monitoring === "OFF" && (
            <p className="text-xs text-amber-400 mt-1">
              Real-time monitoring has been disabled. Historical data remains available.
            </p>
          )}
        </div>
        <Toggle checked={snapshot.monitoring === "ON"} onChange={toggleMonitoring} />
      </div>

      <div className="card p-5 flex items-center justify-between">
        <div>
          <p className="font-medium text-sm">Grid Backup Support</p>
          <p className="text-xs text-slate-500">Allow grid power to supplement EV charging when solar is low</p>
        </div>
        <Toggle checked={snapshot.grid.supportActive} onChange={toggleGrid} />
      </div>

      <div className="card p-5 border-red-500/20">
        <div className="flex items-center justify-between">
          <div>
            <p className="font-medium text-sm">System Power</p>
            <p className="text-xs text-slate-500">Turning this OFF stops charging and takes the station offline</p>
          </div>
          <Toggle checked={snapshot.systemPower === "ON"} onChange={toggleSystemPower} />
        </div>
        <div className="flex gap-3 mt-4">
          <StatusBadge status={snapshot.systemPower === "ON" ? "ONLINE" : "OFFLINE"} />
          <StatusBadge status={snapshot.ev.status} />
          <StatusBadge status={snapshot.monitoring === "ON" ? "ACTIVE" : "STANDBY"} />
        </div>
      </div>

      <ConfirmModal
        open={confirmSystemOff}
        title="Turn OFF Charging Station"
        message="Are you sure you want to turn OFF the charging station? This will stop all charging and take the system offline."
        confirmLabel="Turn System OFF"
        danger
        onCancel={() => setConfirmSystemOff(false)}
        onConfirm={confirmSystemOffAction}
      />
    </DashboardLayout>
  );
}
