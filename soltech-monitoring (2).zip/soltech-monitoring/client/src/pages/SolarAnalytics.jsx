import React, { useEffect, useState } from "react";
import DashboardLayout from "../components/DashboardLayout.jsx";
import SolarLineChart from "../charts/SolarLineChart.jsx";
import EnergyBarChart from "../charts/EnergyBarChart.jsx";
import api from "../services/api";
import { getSocket } from "../services/socket";

const FILTERS = [
  { key: "live", label: "LIVE" },
  { key: "today", label: "TODAY" },
  { key: "7days", label: "7 DAYS" },
  { key: "30days", label: "30 DAYS" },
];

export default function SolarAnalytics() {
  const [filter, setFilter] = useState("live");
  const [liveHistory, setLiveHistory] = useState([]);
  const [dailyHistory, setDailyHistory] = useState([]);

  useEffect(() => {
    api.get("/monitoring/history").then((res) => setLiveHistory(res.data));
    const socket = getSocket();
    const handler = () => {
      api.get("/monitoring/history").then((res) => setLiveHistory(res.data));
    };
    socket.on("monitoring:update", handler);
    return () => socket.off("monitoring:update", handler);
  }, []);

  useEffect(() => {
    if (filter === "live") return;
    api.get(`/history?range=${filter}`).then((res) => setDailyHistory(res.data));
  }, [filter]);

  const liveChartData = liveHistory.map((h) => ({
    label: new Date(h.time).toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" }),
    solar: h.solarPowerKw,
    ev: h.evPowerKw,
    grid: h.gridPowerKw,
  }));

  const dailyChartData = dailyHistory.map((h) => ({
    label: h.date.slice(5),
    solar: h.solarGenerationKwh,
    ev: h.evChargingKwh,
    grid: h.gridEnergyKwh,
    efficiency: h.efficiencyPercent,
  }));

  return (
    <DashboardLayout title="Solar Analytics" subtitle="Energy generation & efficiency trends">
      <div className="flex flex-wrap gap-2">
        {FILTERS.map((f) => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key)}
            className={`px-4 py-2 rounded-xl text-xs font-medium transition-colors ${
              filter === f.key ? "bg-solar-600 text-white" : "bg-white/5 text-slate-400 hover:bg-white/10"
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      <div className="card p-5">
        <h3 className="font-semibold mb-4">
          {filter === "live" ? "Time vs Solar Power (kW)" : "Solar, EV & Grid Energy (kWh)"}
        </h3>
        {filter === "live" ? (
          liveChartData.length > 0 ? (
            <SolarLineChart
              data={liveChartData}
              lines={[
                { dataKey: "solar", name: "Solar (kW)", color: "#22c55e" },
                { dataKey: "ev", name: "EV Charging (kW)", color: "#38bdf8" },
                { dataKey: "grid", name: "Grid (kW)", color: "#f59e0b" },
              ]}
            />
          ) : (
            <p className="text-sm text-slate-400 py-10 text-center">Collecting live data points...</p>
          )
        ) : (
          <EnergyBarChart
            data={dailyChartData}
            bars={[
              { dataKey: "solar", name: "Solar (kWh)", color: "#22c55e" },
              { dataKey: "ev", name: "EV Charging (kWh)", color: "#38bdf8" },
              { dataKey: "grid", name: "Grid (kWh)", color: "#f59e0b" },
            ]}
          />
        )}
      </div>

      {filter !== "live" && (
        <div className="card p-5">
          <h3 className="font-semibold mb-4">Solar Panel Efficiency Trend</h3>
          <SolarLineChart
            data={dailyChartData}
            lines={[{ dataKey: "efficiency", name: "Efficiency (%)", color: "#a78bfa" }]}
          />
          <p className="text-[11px] text-slate-500 mt-2">
            Efficiency values are ESTIMATED based on simulated irradiance and temperature — not measured by a
            calibrated irradiance sensor.
          </p>
        </div>
      )}
    </DashboardLayout>
  );
}
