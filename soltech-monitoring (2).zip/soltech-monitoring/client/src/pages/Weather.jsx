import React, { useEffect, useState } from "react";
import DashboardLayout from "../components/DashboardLayout.jsx";
import StatCard from "../components/StatCard.jsx";
import api from "../services/api";
import { getSocket } from "../services/socket";
import { Thermometer, Droplets, Wind, Cloud, Sun, Sunrise, Sunset } from "lucide-react";

export default function Weather() {
  const [weather, setWeather] = useState(null);
  const [snapshot, setSnapshot] = useState(null);

  useEffect(() => {
    api.get("/weather").then((res) => setWeather(res.data));
    api.get("/monitoring").then((res) => setSnapshot(res.data));
    const socket = getSocket();
    socket.on("monitoring:update", setSnapshot);
    return () => socket.off("monitoring:update", setSnapshot);
  }, []);

  return (
    <DashboardLayout title="Live Weather" subtitle="Weather conditions & solar performance estimate">
      {weather && (
        <>
          {weather.source === "MOCK" && (
            <div className="badge bg-amber-500/15 text-amber-400 w-fit">
              SIMULATED WEATHER — configure WEATHER_API_KEY for live data
            </div>
          )}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <StatCard icon={Thermometer} label="Temperature" value={weather.temperature} unit="°C" />
            <StatCard icon={Cloud} label="Weather Condition" value={weather.condition} />
            <StatCard icon={Droplets} label="Humidity" value={weather.humidity} unit="%" />
            <StatCard icon={Wind} label="Wind Speed" value={weather.windSpeed} unit="m/s" />
            <StatCard icon={Cloud} label="Cloud Cover" value={weather.cloudPercent} unit="%" />
            <StatCard icon={Sun} label="UV Index" value={weather.uvIndex ?? "N/A"} />
            <StatCard icon={Sunrise} label="Sunrise" value={weather.sunrise} />
            <StatCard icon={Sunset} label="Sunset" value={weather.sunset} />
          </div>
        </>
      )}

      {snapshot && weather && (
        <div className="card p-5 space-y-3">
          <h3 className="font-semibold">Weather ↔ Solar Performance</h3>
          <div className="grid grid-cols-2 lg:grid-cols-5 gap-4 text-sm">
            <StatCard label="Weather" value={weather.condition} />
            <StatCard label="Temperature" value={weather.temperature} unit="°C" />
            <StatCard label="Cloud Cover" value={weather.cloudPercent} unit="%" />
            <StatCard label="Solar Generation" value={snapshot.solar.powerKw} unit="kW" />
            <StatCard label="Panel Efficiency" value={snapshot.solar.panelEfficiencyPercent} unit="%" hint="Estimated" />
          </div>
          <p className="text-xs text-slate-500 pt-2">
            Solar efficiency may vary depending on sunlight intensity, temperature, cloud cover and environmental
            conditions.
          </p>
        </div>
      )}
    </DashboardLayout>
  );
}
