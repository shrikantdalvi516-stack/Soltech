/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  darkMode: "class",
  theme: {
    extend: {
      colors: {
        solar: {
          50: "#f0fdf4",
          100: "#dcfce7",
          400: "#4ade80",
          500: "#22c55e",
          600: "#16a34a",
          700: "#15803d",
          900: "#14532d",
        },
        graphite: {
          800: "#1e2530",
          850: "#171d26",
          900: "#11151c",
          950: "#0b0e13",
        },
      },
      boxShadow: {
        card: "0 4px 24px -6px rgba(0,0,0,0.15)",
      },
    },
  },
  plugins: [],
};
