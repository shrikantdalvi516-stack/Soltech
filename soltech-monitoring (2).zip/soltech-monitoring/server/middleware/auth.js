const jwt = require("jsonwebtoken");

function requireAuth(req, res, next) {
  const token =
    (req.cookies && req.cookies.soltech_token) ||
    (req.headers.authorization && req.headers.authorization.split(" ")[1]);

  if (!token) {
    return res.status(401).json({ message: "Not authenticated" });
  }

  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    req.user = payload;
    next();
  } catch (err) {
    return res.status(401).json({ message: "Session expired, please log in again" });
  }
}

module.exports = { requireAuth };
