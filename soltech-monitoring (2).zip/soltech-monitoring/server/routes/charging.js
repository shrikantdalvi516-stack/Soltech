const express = require("express");
const { requireAuth } = require("../middleware/auth");
const sensorService = require("../services/mockSensorService");

const router = express.Router();

router.get("/", requireAuth, (req, res) => {
  res.json(sensorService.getSnapshot().ev);
});

router.post("/start", requireAuth, (req, res) => {
  try {
    const state = sensorService.startCharging();
    res.json({ message: "Charging started", state });
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

router.post("/pause", requireAuth, (req, res) => {
  const state = sensorService.pauseCharging();
  res.json({ message: "Charging paused", state });
});

router.post("/stop", requireAuth, (req, res) => {
  const state = sensorService.stopCharging();
  res.json({ message: "Charging stopped", state });
});

router.post("/limit", requireAuth, (req, res) => {
  const { kw } = req.body;
  const state = sensorService.setChargingLimit(kw);
  res.json({ message: `Charging power limit set to ${kw} kW`, state });
});

module.exports = router;
