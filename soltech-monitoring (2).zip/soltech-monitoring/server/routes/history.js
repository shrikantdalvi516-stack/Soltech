const express = require("express");
const fs = require("fs");
const path = require("path");
const { requireAuth } = require("../middleware/auth");

const router = express.Router();
const HISTORY_FILE = path.join(__dirname, "..", "data", "history.json");
const ALERTS_FILE = path.join(__dirname, "..", "data", "alerts.json");
const CHANGELOG_FILE = path.join(__dirname, "..", "data", "changelog.json");

function readJson(file) {
  return JSON.parse(fs.readFileSync(file, "utf-8"));
}

function filterByRange(rows, range) {
  if (!range || range === "all") return rows;
  const today = new Date("2026-08-27");
  const days = { today: 0, yesterday: 1, "7days": 7, "30days": 30 }[range];
  if (days === undefined) return rows;
  const cutoff = new Date(today);
  cutoff.setDate(cutoff.getDate() - days);
  return rows.filter((r) => new Date(r.date) >= cutoff);
}

// GET /api/history?range=today|yesterday|7days|30days
router.get("/", requireAuth, (req, res) => {
  const rows = readJson(HISTORY_FILE);
  res.json(filterByRange(rows, req.query.range));
});

// GET /api/history/export.csv?range=...
router.get("/export.csv", requireAuth, (req, res) => {
  const rows = filterByRange(readJson(HISTORY_FILE), req.query.range);
  const headers = [
    "Date",
    "Time",
    "Solar Generation (kWh)",
    "EV Charging Energy (kWh)",
    "Grid Energy (kWh)",
    "Efficiency (%)",
    "Charging Duration",
    "System Status",
  ];
  const lines = [headers.join(",")];
  rows.forEach((r) => {
    lines.push(
      [
        r.date,
        r.time,
        r.solarGenerationKwh,
        r.evChargingKwh,
        r.gridEnergyKwh,
        r.efficiencyPercent,
        r.chargingDuration,
        r.systemStatus,
      ].join(",")
    );
  });

  res.setHeader("Content-Type", "text/csv");
  res.setHeader("Content-Disposition", "attachment; filename=soltech-history.csv");
  res.send(lines.join("\n"));
});

// ---- Alerts ----
router.get("/alerts", requireAuth, (req, res) => {
  res.json(readJson(ALERTS_FILE));
});

// ---- Change Catalogue ----
router.get("/changelog", requireAuth, (req, res) => {
  res.json(readJson(CHANGELOG_FILE));
});

router.post("/changelog", requireAuth, (req, res) => {
  const { version, date, feature, description, developer, status } = req.body;
  if (!version || !feature) {
    return res.status(400).json({ message: "version and feature are required" });
  }
  const rows = readJson(CHANGELOG_FILE);
  rows.push({ version, date, feature, description, developer, status: status || "Completed" });
  fs.writeFileSync(CHANGELOG_FILE, JSON.stringify(rows, null, 2));
  res.status(201).json({ message: "Changelog entry added", rows });
});

module.exports = router;
