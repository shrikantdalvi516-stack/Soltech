const express = require("express");
const { requireAuth } = require("../middleware/auth");
const sensorService = require("../services/mockSensorService");

const router = express.Router();

// GET /api/monitoring - full current snapshot (used by dashboard + real-time page)
router.get("/", requireAuth, (req, res) => {
  res.json(sensorService.getSnapshot());
});

// GET /api/monitoring/history - short in-memory buffer for LIVE chart mode
router.get("/history", requireAuth, (req, res) => {
  res.json(sensorService.getRecentHistory());
});

// POST /api/monitoring/toggle - turn real-time monitoring ON/OFF (keeps historical data)
router.post("/toggle", requireAuth, (req, res) => {
  const { on } = req.body;
  const state = sensorService.setMonitoring(on);
  res.json({ message: on ? "Monitoring enabled" : "Real-time monitoring has been disabled.", state });
});

// POST /api/system/power - turn the whole station ON/OFF (critical, confirmed on frontend)
router.post("/system/power", requireAuth, (req, res) => {
  const { on } = req.body;
  const state = sensorService.setSystemPower(on);
  res.json({
    message: on ? "System powered ON" : "Charging station turned OFF",
    state,
  });
});

// POST /api/system/mode - AUTO / MANUAL
router.post("/system/mode", requireAuth, (req, res) => {
  try {
    const state = sensorService.setMode(req.body.mode);
    res.json({ message: `Mode set to ${req.body.mode}`, state });
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// POST /api/system/grid-support - toggle grid backup
router.post("/system/grid-support", requireAuth, (req, res) => {
  const state = sensorService.setGridSupport(req.body.on);
  res.json({ message: `Grid support ${req.body.on ? "enabled" : "disabled"}`, state });
});

module.exports = router;
