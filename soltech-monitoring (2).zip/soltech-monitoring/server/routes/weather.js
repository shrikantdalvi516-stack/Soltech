const express = require("express");
const { requireAuth } = require("../middleware/auth");
const { getWeather } = require("../services/weatherService");

const router = express.Router();

router.get("/", requireAuth, async (req, res) => {
  try {
    const weather = await getWeather();
    res.json(weather);
  } catch (err) {
    res.status(500).json({ message: "Weather API Error", error: err.message });
  }
});

module.exports = router;
