require("dotenv").config();

const express = require("express");
const http = require("http");
const cors = require("cors");
const cookieParser = require("cookie-parser");
const { Server } = require("socket.io");

const authRoutes = require("./routes/auth");
const monitoringRoutes = require("./routes/monitoring");
const chargingRoutes = require("./routes/charging");
const weatherRoutes = require("./routes/weather");
const historyRoutes = require("./routes/history");
const sensorService = require("./services/mockSensorService");

const app = express();
const server = http.createServer(app);

const CLIENT_URL = process.env.CLIENT_URL || "http://localhost:5173";

// Allow the configured CLIENT_URL plus any device on the same local network
// (e.g. http://192.168.x.x:5173) so the dashboard can be opened from a
// phone or another laptop on the same WiFi during development/demo.
const LAN_ORIGIN_REGEX = /^http:\/\/(localhost|127\.0\.0\.1|10\.\d+\.\d+\.\d+|192\.168\.\d+\.\d+|172\.(1[6-9]|2\d|3[0-1])\.\d+\.\d+):\d+$/;

function corsOriginCheck(origin, callback) {
  if (!origin || origin === CLIENT_URL || LAN_ORIGIN_REGEX.test(origin)) {
    return callback(null, true);
  }
  return callback(new Error("Not allowed by CORS"));
}

const io = new Server(server, {
  cors: { origin: corsOriginCheck, credentials: true },
});

app.use(cors({ origin: corsOriginCheck, credentials: true }));
app.use(express.json());
app.use(cookieParser());

// ---------------- REST API ----------------
// Future hardware integration surfaces (ESP32 / Arduino / MQTT / Modbus /
// solar inverter API / EV charger API) should plug into the services layer
// referenced by these routes — see mockSensorService.js header comment.
app.use("/api/auth", authRoutes);
app.use("/api/monitoring", monitoringRoutes);
app.use("/api/charging", chargingRoutes);
app.use("/api/weather", weatherRoutes);
app.use("/api/history", historyRoutes);

app.get("/api/health", (req, res) => {
  res.json({ status: "ok", dataMode: sensorService.DATA_MODE });
});

// ---------------- Socket.IO real-time push ----------------
// Broadcasts a fresh sensor snapshot to all connected dashboard clients
// every 3 seconds. When real hardware is wired up, this loop can instead
// be triggered by an MQTT message handler pushing data as it arrives.
io.on("connection", (socket) => {
  console.log("Client connected:", socket.id);
  socket.emit("monitoring:update", sensorService.getSnapshot());

  socket.on("disconnect", () => {
    console.log("Client disconnected:", socket.id);
  });
});

setInterval(() => {
  const snapshot = sensorService.getSnapshot();
  io.emit("monitoring:update", snapshot);
}, 3000);

const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
  console.log(`SOLTECH Monitoring server running on port ${PORT} [DATA_MODE=${sensorService.DATA_MODE}]`);
});
