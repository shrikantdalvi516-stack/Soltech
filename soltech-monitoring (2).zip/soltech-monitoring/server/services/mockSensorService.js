/**
 * MockSensorService
 * ------------------
 * Generates realistic, continuously-evolving simulated sensor data for the
 * Solar Powered EV Charging Station when no physical hardware is connected.
 *
 * >>> HOW TO REPLACE WITH REAL HARDWARE <<<
 * Create a `RealIoTSensorService.js` in this same folder that implements the
 * exact same method signatures (getSnapshot(), getState(), startCharging(),
 * stopCharging(), pauseCharging(), setMode(), setSystemPower()).
 * That service would instead:
 *   - Read live values from ESP32 / Arduino boards over Serial/WiFi
 *   - Subscribe to an MQTT broker topic (e.g. "soltech/solar/#")
 *   - Poll a Modbus register on the solar inverter
 *   - Call the EV charger's vendor REST API
 * Then in server.js, swap:
 *     const sensorService = require('./services/mockSensorService');
 *   for:
 *     const sensorService = require('./services/realIoTSensorService');
 * No other code needs to change because the interface is identical.
 */

const DATA_MODE = process.env.DATA_MODE || "MOCK"; // MOCK | LIVE

// ---- Internal mutable state (simulates a real running station) ----
let state = {
  systemPower: "ON", // ON | OFF
  monitoring: "ON", // ON | OFF
  mode: "AUTO", // AUTO | MANUAL
  chargingStatus: "CHARGING", // READY | CHARGING | PAUSED | STOPPED
  evConnected: true,
  evBatteryPercent: 62,
  chargingStartedAt: Date.now() - 1000 * 60 * 84, // ~1h24m ago
  energyDeliveredKwh: 8.42,
  todaysEnergyKwh: 28.6,
  totalEnergyKwh: 18452.3,
  gridSupport: false,
  chargingPowerLimitKw: 7.4,
};

let history = []; // rolling in-memory buffer of recent snapshots (for LIVE chart)
const MAX_HISTORY_POINTS = 200;

function clamp(val, min, max) {
  return Math.max(min, Math.min(max, val));
}

function randomWalk(current, min, max, step) {
  const next = current + (Math.random() - 0.5) * step;
  return Number(clamp(next, min, max).toFixed(2));
}

// Simple day-based solar irradiance curve (0 at night, peak at noon)
function solarIrradianceFactor() {
  const now = new Date();
  const hour = now.getHours() + now.getMinutes() / 60;
  // Bell curve centered at 13:00, active 06:00-19:00
  if (hour < 6 || hour > 19) return 0.02;
  const x = (hour - 13) / 4.5;
  return Number(clamp(Math.exp(-(x * x)), 0.02, 1).toFixed(3));
}

let lastValues = {
  solarVoltage: 380,
  solarCurrent: 12.5,
  panelTemp: 42,
  ambientTemp: 30,
};

function computeSnapshot() {
  const irradiance = solarIrradianceFactor();
  const isOff = state.systemPower === "OFF";

  const solarVoltage = isOff ? 0 : randomWalk(lastValues.solarVoltage, 340, 410, 4);
  const solarCurrent = isOff ? 0 : Number((randomWalk(lastValues.solarCurrent, 2, 22, 1.2) * irradiance).toFixed(2));
  const solarPowerKw = Number(((solarVoltage * solarCurrent) / 1000).toFixed(2));

  const panelTemp = randomWalk(lastValues.panelTemp, 25, 58, 1.5);
  const ambientTemp = randomWalk(lastValues.ambientTemp, 22, 38, 0.8);

  const efficiencyBase = 90 - (panelTemp - 25) * 0.35; // heat reduces efficiency
  const panelEfficiency = Number(clamp(efficiencyBase * (0.85 + irradiance * 0.15), 40, 94).toFixed(1));

  const evCharging = !isOff && state.chargingStatus === "CHARGING" && state.evConnected;
  const evVoltage = evCharging ? Number(randomWalk(230, 220, 240, 2).toFixed(1)) : 0;
  const evCurrent = evCharging ? Number(clamp(state.chargingPowerLimitKw * 1000 / evVoltage, 10, 32).toFixed(1)) : 0;
  const evPowerKw = Number(((evVoltage * evCurrent) / 1000).toFixed(2));

  const gridPowerKw = state.gridSupport && evCharging ? Number(clamp(evPowerKw - solarPowerKw, 0, 5).toFixed(2)) : 0;

  lastValues = { solarVoltage, solarCurrent, panelTemp, ambientTemp };

  if (evCharging) {
    // increment energy delivered roughly per tick (assuming ~3s ticks)
    state.energyDeliveredKwh = Number((state.energyDeliveredKwh + evPowerKw * (3 / 3600)).toFixed(3));
    state.todaysEnergyKwh = Number((state.todaysEnergyKwh + solarPowerKw * (3 / 3600)).toFixed(3));
    state.totalEnergyKwh = Number((state.totalEnergyKwh + solarPowerKw * (3 / 3600)).toFixed(3));
    state.evBatteryPercent = Number(clamp(state.evBatteryPercent + 0.01, 0, 100).toFixed(2));
  }

  const chargingDurationSec = state.chargingStatus === "CHARGING"
    ? Math.floor((Date.now() - state.chargingStartedAt) / 1000)
    : 0;

  const estRemainingSec = evCharging
    ? Math.floor(((100 - state.evBatteryPercent) / 100) * 3600 * 4)
    : 0;

  const snapshot = {
    timestamp: new Date().toISOString(),
    dataMode: DATA_MODE,
    systemPower: state.systemPower,
    monitoring: state.monitoring,
    mode: state.mode,
    solar: {
      voltage: solarVoltage,
      current: solarCurrent,
      powerKw: solarPowerKw,
      irradianceFactor: irradiance,
      panelTemp,
      panelEfficiencyPercent: panelEfficiency, // ESTIMATED — see note in API response
      efficiencyIsEstimated: true,
    },
    environment: {
      ambientTemp,
    },
    ev: {
      connected: state.evConnected,
      status: state.chargingStatus,
      batteryPercent: Number(state.evBatteryPercent.toFixed(1)),
      voltage: evVoltage,
      current: evCurrent,
      powerKw: evPowerKw,
      energyDeliveredKwh: state.energyDeliveredKwh,
      chargingDurationSec,
      estRemainingSec,
      chargingPowerLimitKw: state.chargingPowerLimitKw,
    },
    grid: {
      supportActive: state.gridSupport,
      powerKw: gridPowerKw,
    },
    energy: {
      todaysEnergyKwh: Number(state.todaysEnergyKwh.toFixed(2)),
      totalEnergyKwh: Number(state.totalEnergyKwh.toFixed(1)),
    },
  };

  history.push({
    time: new Date().toISOString(),
    solarPowerKw,
    evPowerKw,
    gridPowerKw,
    efficiency: panelEfficiency,
  });
  if (history.length > MAX_HISTORY_POINTS) history.shift();

  return snapshot;
}

function getSnapshot() {
  return computeSnapshot();
}

function getRecentHistory() {
  return history;
}

function getState() {
  return { ...state };
}

function startCharging() {
  if (state.systemPower === "OFF") throw new Error("System is OFF");
  state.chargingStatus = "CHARGING";
  state.chargingStartedAt = Date.now();
  return getState();
}

function pauseCharging() {
  state.chargingStatus = "PAUSED";
  return getState();
}

function stopCharging() {
  state.chargingStatus = "STOPPED";
  return getState();
}

function setMode(mode) {
  if (!["AUTO", "MANUAL"].includes(mode)) throw new Error("Invalid mode");
  state.mode = mode;
  return getState();
}

function setChargingLimit(kw) {
  state.chargingPowerLimitKw = clamp(Number(kw), 1, 22);
  return getState();
}

function setGridSupport(on) {
  state.gridSupport = !!on;
  return getState();
}

function setMonitoring(on) {
  state.monitoring = on ? "ON" : "OFF";
  return getState();
}

function setSystemPower(on) {
  state.systemPower = on ? "ON" : "OFF";
  if (!on) {
    state.chargingStatus = "STOPPED";
  }
  return getState();
}

module.exports = {
  DATA_MODE,
  getSnapshot,
  getRecentHistory,
  getState,
  startCharging,
  pauseCharging,
  stopCharging,
  setMode,
  setChargingLimit,
  setGridSupport,
  setMonitoring,
  setSystemPower,
};
