/**
 * weatherService.js
 * Fetches live weather from OpenWeather API using WEATHER_API_KEY.
 * The API key is NEVER sent to the frontend — the frontend only calls
 * our own /api/weather endpoint, and this service calls OpenWeather
 * server-side.
 *
 * If no API key is configured, falls back to a clearly-labeled mock
 * weather generator so the dashboard still works out of the box.
 */

const API_KEY = process.env.WEATHER_API_KEY;
const CITY = process.env.WEATHER_CITY || "Pune,IN";

function mockWeather() {
  const conditions = ["Clear Sky", "Partly Cloudy", "Cloudy", "Light Rain", "Haze"];
  const condition = conditions[Math.floor(Math.random() * conditions.length)];
  return {
    source: "MOCK",
    city: CITY,
    temperature: Number((28 + Math.random() * 6).toFixed(1)),
    condition,
    humidity: Math.floor(45 + Math.random() * 30),
    windSpeed: Number((2 + Math.random() * 6).toFixed(1)),
    cloudPercent: Math.floor(Math.random() * 70),
    uvIndex: Number((3 + Math.random() * 6).toFixed(1)),
    sunrise: "06:12 AM",
    sunset: "06:48 PM",
  };
}

async function getWeather() {
  if (!API_KEY || API_KEY === "your_openweathermap_api_key_here") {
    return mockWeather();
  }

  try {
    const url = `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(
      CITY
    )}&appid=${API_KEY}&units=metric`;
    const res = await fetch(url);
    if (!res.ok) throw new Error(`OpenWeather API error: ${res.status}`);
    const data = await res.json();

    const toTime = (unixTs, tzOffsetSec) => {
      const d = new Date((unixTs + tzOffsetSec) * 1000);
      return d.toISOString().substr(11, 5);
    };

    return {
      source: "LIVE",
      city: data.name,
      temperature: data.main?.temp,
      condition: data.weather?.[0]?.main || "Unknown",
      humidity: data.main?.humidity,
      windSpeed: data.wind?.speed,
      cloudPercent: data.clouds?.all,
      uvIndex: null, // requires separate One Call API endpoint
      sunrise: toTime(data.sys?.sunrise, data.timezone || 0),
      sunset: toTime(data.sys?.sunset, data.timezone || 0),
    };
  } catch (err) {
    console.error("Weather API fetch failed, falling back to mock:", err.message);
    return mockWeather();
  }
}

module.exports = { getWeather };
